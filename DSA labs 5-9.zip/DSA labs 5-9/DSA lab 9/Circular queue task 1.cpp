#include <iostream>
using namespace std;

// Structure for a Node
struct Node {
    int data;
    Node* link;
};

// Structure for Queue
struct Queue {
    Node* front;
    Node* rear;
};

// Function to create Circular Queue
void enQueue(Queue* q, int value) {
    Node* temp = new Node();
    temp->data = value;
    temp->link = NULL;

    if (q->front == NULL) {
        q->front = temp;
    } else {
        q->rear->link = temp;
    }

    q->rear = temp;
    q->rear->link = q->front; // Circular link
}

// Function to delete element from Circular Queue
int deQueue(Queue* q) {
    if (q->front == NULL) {
        cout << "Queue is empty" << endl;
        return -1;
    }

    int value;

    // If this is the last node
    if (q->front == q->rear) {
        value = q->front->data;
        delete q->front;
        q->front = q->rear = NULL;
    } else {
        Node* temp = q->front;
        value = temp->data;
        q->front = q->front->link;
        q->rear->link = q->front;
        delete temp;
    }
    return value;
}

// Function to display elements of Circular Queue
void displayQueue(Queue* q) {
    if (q->front == NULL) {
        cout << "\nQueue is empty";
        return;
    }

    Node* temp = q->front;
    cout << "\nElements in Circular Queue are: ";
    while (temp->link != q->front) {
        cout << temp->data << " ";
        temp = temp->link;
    }
    cout << temp->data;
}

// Driver Code
int main() {
    Queue q;
    q.front = q.rear = NULL;

    // Inserting elements in Circular Queue
    enQueue(&q, 14);
    enQueue(&q, 22);
    enQueue(&q, 6);

    // Display elements
    displayQueue(&q);

    // Deleting elements
    cout << "\nDeleted value = " << deQueue(&q);
    cout << "\nDeleted value = " << deQueue(&q);

    // Display remaining elements
    displayQueue(&q);

    enQueue(&q, 9);
    enQueue(&q, 20);
    displayQueue(&q);

    return 0;
}

