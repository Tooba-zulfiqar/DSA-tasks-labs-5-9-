#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* next;
};

// Head pointer
Node* head = NULL;

// Function to create a new node
Node* createNode(int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

// Insert at beginning
void insertAtBeginning(int value) {
    Node* newNode = createNode(value);

    if (head == NULL) { // If list is empty
        head = newNode;
        newNode->next = head;
        return;
    }

    Node* temp = head;
    while (temp->next != head) {
        temp = temp->next;
    }

    newNode->next = head;
    temp->next = newNode;
    head = newNode;
}

// Insert after a specific value
void insertAfterValue(int value, int newValue) {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == value) {
            Node* newNode = createNode(newValue);
            newNode->next = temp->next;
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Value " << value << " not found!\n";
}

// Delete at beginning
void deleteAtBeginning() {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    if (head->next == head) { // Only one node
        delete head;
        head = NULL;
        return;
    }

    Node* temp = head;
    while (temp->next != head) {
        temp = temp->next;
    }

    Node* delNode = head;
    temp->next = head->next;
    head = head->next;
    delete delNode;
}

// Delete after a specific value
void deleteAfterValue(int value) {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == value) {
            Node* delNode = temp->next;
            if (delNode == head) {
                cout << "Cannot delete head using this operation!\n";
                return;
            }
            temp->next = delNode->next;
            delete delNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Value " << value << " not found!\n";
}

// Display list
void displayList() {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Node* temp = head;
    cout << "Circular Linked List: ";
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(Head)\n";
}

// Main function
int main() {
    // Creating list manually
    insertAtBeginning(12);
    insertAtBeginning(60);
    insertAtBeginning(45);
    insertAtBeginning(1);

    displayList();

    cout << "\nInsert 100 at beginning:\n";
    insertAtBeginning(100);
    displayList();

    cout << "\nInsert 200 after 45:\n";
    insertAfterValue(45, 200);
    displayList();

    cout << "\nDelete at beginning:\n";
    deleteAtBeginning();
    displayList();

    cout << "\nDelete node after 45:\n";
    deleteAfterValue(45);
    displayList();

    return 0;
}




